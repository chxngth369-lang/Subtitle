import { pgTable, serial, text, timestamp, integer, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export type SegmentRow = {
  id: number;
  start: number;
  end: number;
  text: string;
};

export type ClipSuggestion = {
  id: number;
  start: number;
  end: number;
  title: string;
  text: string;
};

export const transcriptionsTable = pgTable("transcriptions", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  filename: text("filename").notNull(),
  mediaType: text("media_type").notNull(),
  language: text("language").notNull(),
  duration: real("duration").notNull(),
  segmentCount: integer("segment_count").notNull(),
  wordCount: integer("word_count").notNull(),
  fullText: text("full_text").notNull(),
  segments: jsonb("segments").$type<SegmentRow[]>().notNull().default([]),
  mediaObjectPath: text("media_object_path"),
  clips: jsonb("clips").$type<ClipSuggestion[]>(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTranscriptionSchema = createInsertSchema(transcriptionsTable).omit({
  id: true,
  createdAt: true,
});

export type InsertTranscription = z.infer<typeof insertTranscriptionSchema>;
export type Transcription = typeof transcriptionsTable.$inferSelect;
